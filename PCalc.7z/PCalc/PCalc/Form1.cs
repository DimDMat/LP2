﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }


        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtNumero2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void BtnMais_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtNumero1.Text, out numero1)) && (double.TryParse(txtNumero2.Text, out numero2)))
            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();

                //BtnLimpar_Click(sender, e);
            }
            else
                MessageBox.Show("Números inválidos!!");
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtNumero1.Text, out numero1)) && (double.TryParse(txtNumero2.Text, out numero2)))
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();

                //BtnLimpar_Click(sender, e);
            }
            else
                MessageBox.Show("Números inválidos!!");
        }

        private void BtnVezes_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtNumero1.Text, out numero1)) && (double.TryParse(txtNumero2.Text, out numero2)))
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();

                //BtnLimpar_Click(sender, e);
            }
            else
                MessageBox.Show("Números inválidos!!");
        }

        private void TxtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido");
                // txtNumero1.Focus():
            }
        }

        private void TxtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido");
                // txtNumero2.Focus():
            }
        }

        private void BtnDivisao_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtNumero1.Text, out numero1)) && (double.TryParse(txtNumero2.Text, out numero2)))
            {
                if (numero2 != 0)
                {
                    resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString();
                }
                else
                { 
                    MessageBox.Show("Número 2 inválido!");
                    txtNumero2.Focus();
                }
                //BtnLimpar_Click(sender, e);
            }
            else
                MessageBox.Show("Números inválidos!!");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Clear();
            txtResultado.Text = String.Empty;

        }

        private void TxtNumero1_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
